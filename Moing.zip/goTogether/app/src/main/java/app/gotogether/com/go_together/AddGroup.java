package app.gotogether.com.go_together;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class AddGroup extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_group);
    }
}
